/*Kartero App Configuration*/
var krms_driver_config ={	
	'ApiUrl':"",						
	'DialogDefaultTitle':"Kartero",    
	'APIHasKey':"",
	'debug': false
};